package Fordyce;

import java.util.Arrays;

import javax.swing.JOptionPane;

public class FirstFiftyNumbersOfFibanacciSequance
{

	public FirstFiftyNumbersOfFibanacciSequance()
	{
		userChoiceIdentifier();
	}

	public void userChoiceIdentifier()
	{
		String userChoice;
		userChoice = JOptionPane.showInputDialog(
				"Do you want to calculate the first 50 numbers or do you wish to close the program. Either enter calculate the numbers or end the program");

		if (userChoice.equalsIgnoreCase("calculate the numbers"))
		{
			displayFirstFiftyNumbers(firstFiftyToOutputString(firstFiftyFibonacciNumbers()));
		} else if (userChoice.equalsIgnoreCase("end the program"))
		{
			programExitDisplay();
			System.exit(0);
		} else
		{
			errorMessage();
		}
	}

	public void errorMessage()
	{
		JOptionPane.showMessageDialog(null, " Your input was invalid");
		userChoiceIdentifier();
	}

	public long[] firstFiftyFibonacciNumbers()
	{
		long firstFiftyNumbersOfFibonacciSequence[] = new long[50];
		long termOne = 0;
		long termTwo = 1;
		long result;

		for (int count = 0; count < firstFiftyNumbersOfFibonacciSequence.length; count++)
		{
			firstFiftyNumbersOfFibonacciSequence[count] = termOne + termTwo;

			result = termOne + termTwo;
			System.out.println(result);
			firstFiftyNumbersOfFibonacciSequence[count] = result;
			termOne = termTwo;
			termTwo = result;

		}

		return firstFiftyNumbersOfFibonacciSequence;
	}

	public void displayFirstFiftyNumbers(String outputString)
	{

		JOptionPane.showMessageDialog(null, "The first 50 numbers are " + outputString + ".");

	}

	public String firstFiftyToOutputString(long[] firstFiftyNumbersOfFibonacciSequence)
	{
		String outputString = "";

		for (int count = 0; count < firstFiftyNumbersOfFibonacciSequence.length; count++)
		{
			outputString += firstFiftyNumbersOfFibonacciSequence[count] + ", ";

			if (count % 10 == 0)
			{
				outputString += "\n";
			}
		}
		return outputString;
	}

	public void programExitDisplay()
	{
		JOptionPane.showMessageDialog(null, " The program is now closing");
	}

}
